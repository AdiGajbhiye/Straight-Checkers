package com.company;

public class Move {
    short n;
    int []m =  new int[16];

}
