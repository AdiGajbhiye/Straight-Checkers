package com.company;

public class Main {

    public static void main(String[] args) {
        // write your code here
    /*    board representation: the standard checkers notation is

                (white)
        32  31  30  29
        28  27  26  25
        24  23  22  21
        20  19  18  17
        16  15  14  13
        12  11  10   9
        8   7   6   5
        4   3   2   1
        (black)*/

        int[][] b = new int[8][8];

        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                b[r][c] = SimpleEngine.OCCUPIED;
            }
        }

        int count = 32;

        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                b[r][c] = SimpleEngine.OCCUPIED;
            }
        }

        b[0][0] = SimpleEngine.BLACKPAWN;
        b[2][0] = SimpleEngine.BLACKPAWN;
        b[4][0] = SimpleEngine.BLACKPAWN;
        b[6][0] = SimpleEngine.BLACKPAWN;

        b[1][1] = SimpleEngine.BLACKPAWN;
        b[3][1] = SimpleEngine.BLACKPAWN;
        b[5][1] = SimpleEngine.BLACKPAWN;
        b[7][1] = SimpleEngine.BLACKPAWN;

        b[0][2] = SimpleEngine.BLACKPAWN;
        b[2][2] = SimpleEngine.BLACKPAWN;
        b[4][2] = SimpleEngine.BLACKPAWN;
        b[6][2] = SimpleEngine.BLACKPAWN;

        b[1][5] = SimpleEngine.WHITEPAWN;
        b[3][5] = SimpleEngine.WHITEPAWN;
        b[5][5] = SimpleEngine.WHITEPAWN;
        b[7][5] = SimpleEngine.WHITEPAWN;

        b[0][6] = SimpleEngine.WHITEPAWN;
        b[2][6] = SimpleEngine.WHITEPAWN;
        b[4][6] = SimpleEngine.WHITEPAWN;
        b[6][6] = SimpleEngine.WHITEPAWN;

        b[1][7] = SimpleEngine.WHITEPAWN;
        b[3][7] = SimpleEngine.WHITEPAWN;
        b[5][7] = SimpleEngine.WHITEPAWN;
        b[7][7] = SimpleEngine.WHITEPAWN;

        printBoard(b);


        SimpleEngine engine = new SimpleEngine();
        String str = "";
        engine.getMove(b, SimpleEngine.WHITE, 1.0, str, false, 0, 0);
        System.out.println(str);
        printBoard(b);

        int ret = 0;
        int c = 0;

        while (Math.abs(ret) != 4000) {

            if ((c % 2) == 0)
                ret = engine.getMove(b, SimpleEngine.WHITE, 1.0, str, false, 0, 0);
            else
                ret = engine.getMove(b, SimpleEngine.BLACK, 1.0, str, false, 0, 0);
            c++;
            printBoard(b);
        }

/*
        engine.getMove(b, SimpleEngine.BLACK, 1.0, str,true, 0, 0);
        System.out.println(str);
        printBoard(b);

        engine.getMove(b, SimpleEngine.WHITE, 1.0, str,true, 0, 0);
        System.out.println(str);
        printBoard(b);

        engine.getMove(b, SimpleEngine.BLACK, 1.0, str, true, 0, 0);
        System.out.println(str);
        printBoard(b);

        engine.getMove(b, SimpleEngine.WHITE, 1.0, str, true, 0, 0);
        System.out.println(str);
        printBoard(b);

        engine.getMove(b, SimpleEngine.BLACK, 1.0, str, true, 0, 0);
        System.out.println(str);
        printBoard(b);


        engine.getMove(b, SimpleEngine.WHITE, 1.0, str, true, 0, 0);
        System.out.println(str);
        printBoard(b);*/
    }

    public static void printBoard(int[][] b) {

        for (int r = 7; r >= 0; r--) {
            for (int c = 0; c < 8; c++) {
                if (b[c][r] == SimpleEngine.OCCUPIED)
                    System.out.print("- ");
                else if (b[c][r] == SimpleEngine.WHITEPAWN)
                    System.out.print("W ");
                else if (b[c][r] == SimpleEngine.BLACKPAWN)
                    System.out.print("B ");
                else if (b[c][r] == SimpleEngine.FREE)
                    System.out.print("F ");
                else
                    System.out.print(b[c][r] + " ");

            }
            System.out.println("");
        }

        System.out.println("");
    }
}
